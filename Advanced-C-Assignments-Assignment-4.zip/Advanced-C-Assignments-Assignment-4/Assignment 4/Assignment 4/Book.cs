﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_4
{
    public delegate T GetDelegate<T>(Book value);

    public class Book
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string[] Authors { get; set; }
        public DateTime PublicationDate { get; set; }
        public decimal Price { get; set; }

        public Book(string iSBN, string title, string[] authors, DateTime publiccationDate, decimal price)
        {
            ISBN = iSBN;
            Title = title;
            Authors = authors;
            PublicationDate = publiccationDate;
            Price = price;
        }
        public override string ToString()
        {
            return $"ISBN:{ISBN} \n Title{Title} - Authors:{string.Join(",", Authors)} - Date{PublicationDate.ToShortDateString()} - Price{Price} \n";
        }
    }
    public class BookFunctions
    {
        public static string GetTitle(Book B) { return B.Title; }
        public static string[] GetAuthor(Book B) { return B.Authors; }
        public static decimal GetPrice(Book B) { return B.Price; }
    }

    public class LibraryEngine<T>
    {
        public static void ProcessBooks(List<Book> bList, GetDelegate<T> str) 
        {
            foreach (Book b in bList)
                if (str(b) is string[])
                    Console.WriteLine(string.Join(", ", (string[])(object)str(b)));
                else
                    Console.WriteLine(str(b));
        }
    }
}
