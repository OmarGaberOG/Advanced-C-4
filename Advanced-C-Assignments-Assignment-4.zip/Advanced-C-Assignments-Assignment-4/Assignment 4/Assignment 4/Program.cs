﻿namespace Assignment_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> bList = new List<Book>()
            {
             new Book("A1", "Ard Zekola",new string[] { "Higzo" },new DateTime(2005,8,1), 250),
             new Book("B2", "Mawra Al-Tabe3a",new string[] { "Ashraf","Adham" },new DateTime(2012,5,1), 250)
            };
            #region a) Create User Defined Delegate with the same signature of methods existed in Bookfunctions class.
            //Console.WriteLine("Titles:\n-------");
            //LibraryEngine<string>.ProcessBooks(bList, BookFunctions.GetTitle);

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Auther:\n------");
            //LibraryEngine<string[]>.ProcessBooks(bList, BookFunctions.GetAuthor);

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Price:\n------");
            //LibraryEngine<decimal>.ProcessBooks(bList, BookFunctions.GetPrice);
            #endregion

            #region b) Use the Proper build in delegate. 
            //Console.WriteLine("ISBN:\n-------");
            //Func<Book, string> f00 = delegate (Book b) { return b.ISBN; };
            //LibraryEngine<string>.ProcessBooks(bList, new GetDelegate<string>(f00));

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Titles:\n-------");
            //Func<Book, string> f01 = delegate (Book b) { return b.Title; };
            //LibraryEngine<string>.ProcessBooks(bList, new GetDelegate<string>(f01));

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Auther:\n------");
            //Func<Book, string[]> f02 = delegate (Book b) { return b.Authors; };
            //LibraryEngine<string[]>.ProcessBooks(bList, new GetDelegate<string[]>(f02));

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Publication Date:\n------");
            //Func<Book, DateTime> f03 = delegate (Book b) { return b.PublicationDate; };
            //LibraryEngine<DateTime>.ProcessBooks(bList, new GetDelegate<DateTime>(f03));

            //Console.WriteLine("----------------------");
            //Console.WriteLine("Price:\n------");
            //Func<Book, decimal> f04 = delegate (Book b) { return b.Price; };
            //LibraryEngine<decimal>.ProcessBooks(bList, new GetDelegate<decimal>(f04));
            #endregion

            #region c) Anonymous Method (GetISBN).
            //Console.WriteLine("ISBN:\n-----");
            //Func<Book,string> f1 = delegate(Book b) {  return b.ISBN; };
            //LibraryEngine<string>.ProcessBooks(bList, new GetDelegate<string>(a1));
            #endregion

            #region d) Lambda Expression (GetPublicationDate).
            //Console.WriteLine("Publication Date:\n-----------------");
            //Func<Book, DateTime> f2 = b => b.PublicationDate;
            //LibraryEngine<DateTime>.ProcessBooks(bList, new GetDelegate<DateTime>(f2));
            #endregion
        }
    }
}
